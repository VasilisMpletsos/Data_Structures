package gr.auth.ee.dsproject.crush.node;


public class Node
{
  // TODO Rename and fill the code
}
