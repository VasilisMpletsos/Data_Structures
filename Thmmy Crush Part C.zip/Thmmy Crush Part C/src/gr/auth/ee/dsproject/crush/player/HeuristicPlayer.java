package gr.auth.ee.dsproject.crush.player;

import gr.auth.ee.dsproject.crush.defplayers.AbstractPlayer;

public class HeuristicPlayer implements AbstractPlayer
{
	

}
